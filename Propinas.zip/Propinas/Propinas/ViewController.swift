//
//  ViewController.swift
//  Propinas
//
//  Created by Alumno on 8/30/21.
//  Copyright © 2021 Alumno. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var lblCantidadTotalMasPropina: UILabel!
    @IBOutlet weak var lblCantidadPropina: UILabel!
    @IBOutlet weak var lblPorcentajePropina: UILabel!
    @IBOutlet weak var slcPorcentejePropina: UISlider!
    @IBOutlet weak var txtTotalCuenta: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func doEditEndTotalCuenta(_ sender: Any) {
    }
    
    @IBAction func doChangePorcentajePropina(_ sender: Any) {
        lblPorcentajePropina.text = "\(String(Int(slcPorcentejePropina.value)))%"
        if txtTotalCuenta.text != nil && txtTotalCuenta.text != ""{
            let cuenta = Float(txtTotalCuenta.text!)!
            let porcentaje = Float(Int(slcPorcentejePropina.value))
            let propina = cuenta * (porcentaje / 100.0)
            lblCantidadPropina.text = "$\(String(format: "%.2f", propina))"
            lblCantidadTotalMasPropina.text = "$\(String(format: "%.2f", cuenta + propina))"
        }
    }
    
}

